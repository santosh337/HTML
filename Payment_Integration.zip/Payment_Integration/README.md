# Hosted Link ##
https://santosh337.github.io/HTML/Payment_Integration/

# Hosted Link ##



# Description # 

I have worked on integrating the payment method . 

Razor Pay . Here i have worked on the integration of the libraries where one can do payment from the given webKit libraries . 

I have made one UI where there are products and also the description and mentioned are the price for those products . 


![Screen Shot 2024-02-13 at 12 35 27 PM](https://github.com/santosh337/HTML/assets/19283972/2c11d49c-5e63-48f3-be37-f4834cde093d)

Here from the list there is the increment and decrement of the quantity where user can buy the product in the required form . 

I have also created the razor pay dashboard where are when the user purchase any product can be seen in the transaction History .
![Uploading Screen Shot 2024-02-13 at 12.37.26 PM.png…]()


